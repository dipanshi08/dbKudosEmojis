package com.example.demo.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.repos.*;
import com.example.demo.entity.*;

@Service
public class EmployeeService {

	
	@Autowired
	private EmployeeRepository repo;
	@Autowired
	private BadgesRepository repo1;
	@Autowired
	private MappingTableRepository repo2;
	
	public List<Employee> findAll(){
		return this.repo.findAll();
	}
	
	public int findById(String email_id){
		
		Employee e = this.repo.findById(email_id).get();
		return e.getKudos_points();
	}
	
	public List<Badges> findAll1(){
		return this.repo1.findAll();
	}
	
	public Badges findById1(String badge_id){
		
		return this.repo1.findById(badge_id).get();
		
	}
	
	public Profile getProfile(String email_id){
		List<String> profile = this.repo2.getProfile(email_id);
		List < String > badge_id = new ArrayList<String>();
		List < Integer > badge_count =new ArrayList<Integer>();
		List < String > badge_name = new ArrayList<String>();
		Employee e = this.repo.findById(email_id).get();
		for (String event : profile) {
            String[] data = event.split(",");
            badge_id.add(data[0]);
            badge_count.add(Integer.parseInt(data[2]));
            badge_name.add(data[1]);
        }
		Profile p = new Profile(e,badge_id,badge_count,badge_name);
		//System.out.println(p.toString());
		return p;
	}
	
	/*public void modify(String email_id, int amount)
	{
		Employee e = this.repo.findById(email_id).get();
		e.setKudos_points(e.getKudos_points()-amount);
	}*/
	
	
	public Employee add(Employee entity) {
		return this.repo.save(entity);
	}
}
